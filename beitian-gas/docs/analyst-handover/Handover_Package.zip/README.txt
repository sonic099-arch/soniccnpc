﻿北田公司气井智能分析系统｜分析人员交接包
文档1.0；程序0.4.1；2026-10-23

先看Analyst_Handbook.docx，再填写Requirements_Workbook.xlsx。
工作簿11个可见页，包含11条规则和49项演示配置，不是现场标准。
先填写01工作流程、02字段映射、03导入需求，再确认04规则及后续页。
黄色区域优先填写；所有意见均需业务确认，不代表已开发或已验收。
Measurement_Template.xlsx为真正的测量导入空模板。
Demo_Example.xlsx只有三行演示数据，不用于真实生产。
需求工作簿和手册不会自动导入或修改规则。
填写后的资料、真实生产样本只在单位内网回收，不上传外部仓库或聊天平台。
内网地址：http://10.86.36.43:8080（需先由部署人员启动）。

来源：docs/ANALYST_HANDOVER.md；规则与字段自动来自程序配置。
重建：安装scripts/requirements-docs.txt后运行python scripts/build_analyst_handover.py。
